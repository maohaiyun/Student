package project.demo;

public class ErrorMessage {
    public static final String ERROR_STUDENT_NOT_FOUND = "The Student Cannot be found";
    public static final String ERROR_STUDENT_EXISTS = "The Student Exists";

}
